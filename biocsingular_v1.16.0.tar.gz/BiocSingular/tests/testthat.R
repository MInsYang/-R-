library(BiocSingular)
library(testthat)
test_check("BiocSingular")
