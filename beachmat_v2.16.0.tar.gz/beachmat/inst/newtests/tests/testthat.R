library(testthat)
library(morebeachtests)
test_check("morebeachtests")
