library(testthat)
library(morebeach)
test_check("morebeach")
