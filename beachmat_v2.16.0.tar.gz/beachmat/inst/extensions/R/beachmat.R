# Tags to indicate to beachmat that readers are available.
beachmat_AaronMatrix_integer_input <- TRUE
beachmat_AaronMatrix_character_input <- TRUE

# Tags to indicate to beachmat that writers are available.
beachmat_AaronMatrix_integer_output <- TRUE
beachmat_AaronMatrix_character_output <- TRUE
