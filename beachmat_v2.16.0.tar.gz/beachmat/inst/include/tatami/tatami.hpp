#ifndef TATAMI_TATAMI_HPP
#define TATAMI_TATAMI_HPP

#include "tatami.h"

#endif
